
@FunctionalInterface
interface  Test
{
    void sum();
  }

public class FuctionalInferfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
